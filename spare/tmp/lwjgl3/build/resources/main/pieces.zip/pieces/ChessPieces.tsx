<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="ChessPieces" tilewidth="150" tileheight="150" tilecount="12" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image source="wr.png" width="150" height="150"/>
 </tile>
 <tile id="1">
  <image source="wq.png" width="150" height="150"/>
 </tile>
 <tile id="2">
  <image source="wp.png" width="150" height="150"/>
 </tile>
 <tile id="3">
  <image source="wn.png" width="150" height="150"/>
 </tile>
 <tile id="4">
  <image source="wk.png" width="150" height="150"/>
 </tile>
 <tile id="5">
  <image source="wb.png" width="150" height="150"/>
 </tile>
 <tile id="6">
  <image source="br.png" width="150" height="150"/>
 </tile>
 <tile id="7">
  <image source="bq.png" width="150" height="150"/>
 </tile>
 <tile id="8">
  <image source="bp.png" width="150" height="150"/>
 </tile>
 <tile id="9">
  <image source="bn.png" width="150" height="150"/>
 </tile>
 <tile id="10">
  <image source="bk.png" width="150" height="150"/>
 </tile>
 <tile id="11">
  <image source="bb.png" width="150" height="150"/>
 </tile>
</tileset>
